create database userweb ;
     use userweb ;
     
 create table users(uid int auto_increment primary key,uname varchar(100) not null , email varchar (50) not null unique, country varchar(50) not null, passd varchar(20) not null);
 